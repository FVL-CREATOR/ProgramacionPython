
var_lado=float(input("Introduce el lado de un triángulo equilátero: "))
var_area=1,73205080756887/4*var_lado**2

print(f"El area total del triángulo es: ",var_area)
