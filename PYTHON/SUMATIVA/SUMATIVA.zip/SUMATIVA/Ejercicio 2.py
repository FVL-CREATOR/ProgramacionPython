
var_1=float(input("Introduce el primer numero: "))
var_2=float(input("Introduce el segundo numero: "))
var_total1=var_1+var_2
print(f"el resultado de sumar var_1 y var_2 es:", var_total1)

var_dividendo=int(input("Divide el numero entre tres: "))
var_total2=(var_total1/3)

print(f"el resultado de dividir var_total1 entre 3 es:", var_total2)





